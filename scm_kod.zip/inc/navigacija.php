<nav class="navbar navbar-light sticky-top bg-white flex-md-nowrap p-0 shadow">
  <a class="col-md-3 col-lg-2 mr-0" href="index.php">
    <img src="img/logo.jpg" alt="" class="img-fluid">
  </a>
  <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-toggle="collapse" data-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <ul class="navbar-nav px-4">
    <li class="nav-item text-nowrap">
      <a class="btn btn-success" href="odjava.php">Odjava</a>
    </li>
  </ul>
</nav>
